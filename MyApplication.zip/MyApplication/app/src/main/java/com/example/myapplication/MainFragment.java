package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainFragment extends AppCompatActivity {
        Button ang,bra,sh,here,brng;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_fragment);
        ang = findViewById(R.id.angusbtn);
        here =findViewById(R.id.herebtn);
        bra=findViewById(R.id.brahmanbtn);
        sh =findViewById(R.id.shorbtn);
        brng =findViewById(R.id.branbtn);
        ang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(MainFragment.this, AngusFragment.class);
                startActivity(i);
            }
        });
        here.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(MainFragment.this, herefordFragment.class);
                startActivity(i);
            }
        });
        bra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(MainFragment.this, BrahmanFragment.class);
                startActivity(i);
            }
        });
        sh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(MainFragment.this, Shorthan.class);
                startActivity(i);
            }
        });
        brng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(MainFragment.this,BrangusFragment.class);
                startActivity(i);
            }
        });
    }
}
