package com.litesapp.ftp.utils;


import android.support.v4.app.DialogFragment;

public class DialogViewFragment extends DialogFragment {


}
