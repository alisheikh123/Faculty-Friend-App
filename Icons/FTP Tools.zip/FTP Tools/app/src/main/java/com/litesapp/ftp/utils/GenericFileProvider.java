package com.litesapp.ftp.utils;


import android.support.v4.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
